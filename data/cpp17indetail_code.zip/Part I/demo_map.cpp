// demo_map.cpp
// example for "C++17 In Detail"
// by Bartlomiej Filipek
// 2018

#include <iostream>
#include <map>
 
int main()
{
    std::map<std::string, int> mapUsersAge;
    
    mapUsersAge.emplace("John", 25);
    mapUsersAge.emplace("Steve", 35);
    mapUsersAge.emplace("Alex", 45);
    
	std::map mapCopy(std::begin(mapUsersAge), std::end(mapUsersAge));
    
    if (auto [iter, wasInserted] = mapCopy.insert_or_assign("John", 26); !wasInserted)
        std::cout << iter->first << " reassigned...\n";
        
    for (const auto& [key, value] : mapCopy)
        std::cout << key << ", " << value << '\n';
}