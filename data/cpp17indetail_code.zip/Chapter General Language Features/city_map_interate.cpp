// city_map_iterate.cpp
// example for "C++17 In Detail"
// by Bartlomiej Filipek
// 2018

#include <map>
#include <iostream>
#include <string>

int main()
{
    std::map<std::string, int> mapCityPopulation;
    mapCityPopulation.emplace("Beijing", 21'707'000);
    mapCityPopulation.emplace("Tokyo", 9'273'000);
    mapCityPopulation.emplace("London", 8'787'892);
    mapCityPopulation.emplace("New York", 8'622'698);
    mapCityPopulation.emplace("Rio de Janeiro", 6'520'000);
    
	// structured bindings used rather than .first, .second from returned pair
    for (auto&[city, population] : mapCityPopulation)
        std::cout << city << ": " << population << '\n';
}