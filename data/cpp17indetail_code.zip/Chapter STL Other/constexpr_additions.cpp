// constexpr_additions.cpp
// example for "C++17 In Detail"
// by Bartlomiej Filipek
// 2018

#include <array>

template<typename Range, typename Func, typename T>
constexpr T SimpleAccumulate(Range& range, Func func, T init)
{
    auto i = init;
    for (auto &&obj : range) // begin/end are constexpr
    {
        i += func(obj);
    }
    return i;
}

constexpr int mul2(int i) { return i*2; }

int main()
{
    constexpr std::array arr{ 1, 2, 3 }; // clas deduction...
    
    static_assert(SimpleAccumulate(arr, [](int i) constexpr { 
            return i * 2; // constexpr lambda
        }, 0) == 12);
        
    static_assert(SimpleAccumulate(arr, &mul2, 0) == 12);
    
    return a1[0];
}