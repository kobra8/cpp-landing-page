Source Code for "C++17 In Detail"
By Bartlomiej Filipek

https://www.cppindetail.com/
https://leanpub.com/cpp17indetail

Creative Commons Licence